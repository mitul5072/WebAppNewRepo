# Sample-Azure-DevOps
Sample repository for present how set developer environment for small web app project on Azure DevOps platform.
Blog article on sparkdata.pl
